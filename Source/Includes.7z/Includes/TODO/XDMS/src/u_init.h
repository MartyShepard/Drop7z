
void Init_Decrunchers(void);

