// This file is part of Deark.
// Copyright (C) 2020-2021 Jason Summers
// See the file COPYING for terms of use.

#define DE_VERSION_NUMBER 0x01060400U
#define DE_VERSION_SUFFIX ""
#define DE_COPYRIGHT_YEAR_STRING "2023"
