miniz-c.h (renamed from miniz.c) and miniz.h comprise miniz.
https://github.com/richgel999/miniz/
miniz is MIT-licensed (formerly public domain). See LICENSE-miniz for details.

Some minor changes may have been made for Deark. Changes are marked with
"Added for Deark" comments.
