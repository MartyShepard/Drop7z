#!/usr/bin/env sh
autoreconf -i
